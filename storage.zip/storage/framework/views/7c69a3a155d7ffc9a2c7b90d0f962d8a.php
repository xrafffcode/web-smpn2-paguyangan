<button type="<?php echo e($attributes->get('type', 'button')); ?>" <?php echo e($attributes->merge(['class' => 'btn btn-primary'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH E:\project-2023\smpn-2\web-smpn2\resources\views/components/button/primary.blade.php ENDPATH**/ ?>