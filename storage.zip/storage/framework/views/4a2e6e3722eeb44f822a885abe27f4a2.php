<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="SMPN 2 PAGUYANGAN">
    <title><?php echo e($title); ?></title>


    <link rel="shortcut icon" href="<?php echo e(asset(getWebConfiguration()->logo)); ?>" type="image/x-icon">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/app.css')); ?>?v=<?php echo e(uniqid()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/custom.css')); ?>?v=<?php echo e(uniqid()); ?>">


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <?php echo $__env->yieldPushContent('plugin-styles'); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>

</head>

<body>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <?php echo e($slot); ?>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('frontend/js/app.js')); ?>?v=<?php echo e(uniqid()); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/script.js')); ?>?v=<?php echo e(uniqid()); ?>"></script>

    <?php echo $__env->yieldPushContent('plugin-scripts'); ?>

    <?php echo $__env->yieldPushContent('custom-scripts'); ?>

</body>

</html>
<?php /**PATH E:\project-2023\smpn-2\web-smpn2\resources\views/components/layouts/frontend.blade.php ENDPATH**/ ?>