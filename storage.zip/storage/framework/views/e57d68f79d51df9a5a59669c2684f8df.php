<?php $__env->startPush('plugin-styles'); ?>
    <link href="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<div class="table-responsive">
    <table id="dataTableExample" class="table table-striped">
        <thead>
            <?php echo e($thead); ?>

        </thead>
        <tbody>
            <?php echo e($tbody); ?>

        </tbody>
    </table>
</div>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables-net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script src="<?php echo e(asset('admin/assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php /**PATH E:\project-2023\smpn-2\web-smpn2\resources\views/components/admin/datatable.blade.php ENDPATH**/ ?>