<div class=" bannerSwiper swiper">
    <div class="swiper-wrapper">
        <?php echo e($slot); ?>

    </div>
    <div class="swiper-button-prev d-none d-sm-none d-md-none d-lg-flex"></div>
    <div class="swiper-button-next d-none d-sm-none d-md-none d-lg-flex"></div>
    <div class="swiper-pagination"></div>
</div>
<?php /**PATH E:\project-2023\smpn-2\web-smpn2\resources\views/components/frontend/banner.blade.php ENDPATH**/ ?>