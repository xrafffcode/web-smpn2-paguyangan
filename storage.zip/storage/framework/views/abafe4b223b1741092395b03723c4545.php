<div class="mb-3">
    <label for="<?php echo e($attributes->get('name')); ?>" class="form-label"><?php echo e($attributes->get('label')); ?></label>

    <textarea name="<?php echo e($attributes->get('name')); ?>"
        <?php echo e($attributes->merge(['class' => 'form-control' . ($errors->has($attributes->get('name')) ? ' is-invalid' : '')])); ?>><?php echo e($attributes->get('value')); ?></textarea>

    <?php if($errors->has($attributes->get('name'))): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first($attributes->get('name'))); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH E:\project-2023\smpn-2\web-smpn2\resources\views/components/input/textarea.blade.php ENDPATH**/ ?>