<div class="card">
    <div class="card-body">
        <h6 class="card-title">
            <?php echo e($attributes->get('title')); ?>

        </h6>

        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH E:\project-2023\smpn-2\web-smpn2\resources\views/components/admin/card.blade.php ENDPATH**/ ?>