<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['id', 'label', 'checked' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id', 'label', 'checked' => false]); ?>
<?php foreach (array_filter((['id', 'label', 'checked' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="form-check">
    <input class="form-check-input primary" type="checkbox" <?php echo e($checked ? '' : ''); ?> id="<?php echo e($id); ?>"
        <?php echo e($attributes); ?>>
    <label class="form-check-label text-dark" for="<?php echo e($id); ?>">
        <?php echo e($label); ?>

    </label>
</div>
<?php /**PATH E:\project-2023\smpn-2\web-smpn2\resources\views/components/input/checkbox.blade.php ENDPATH**/ ?>