<div class="mb-3">
    <label for="<?php echo e($attributes->get('name')); ?>" class="form-label"><?php echo e($attributes->get('label')); ?></label>
    <input type="<?php echo e($type ?? 'password'); ?>" name="<?php echo e($attributes->get('name')); ?>" value="<?php echo e($attributes->get('value')); ?>"
        <?php echo e($attributes->merge(['class' => 'form-control' . ($errors->has($attributes->get('name')) ? ' is-invalid' : '')])); ?>>

    <?php if($errors->has($attributes->get('name'))): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first($attributes->get('name'))); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH E:\project-2023\smpn-2\web-smpn2\resources\views/components/input/password.blade.php ENDPATH**/ ?>