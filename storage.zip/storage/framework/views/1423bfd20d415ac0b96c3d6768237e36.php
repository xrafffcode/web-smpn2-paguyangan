<div class="mb-3">
    <label class="form-label" for="<?php echo e($attributes->get('name')); ?>"><?php echo e($attributes->get('label')); ?></label>
    <input
        <?php echo e($attributes->merge(['class' => 'form-control' . ($errors->has($attributes->get('name')) ? ' is-invalid' : '')])); ?>

        type="file" id="<?php echo e($attributes->get('name')); ?>" name="<?php echo e($attributes->get('name')); ?>">
    <?php if($errors->has($attributes->get('name'))): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first($attributes->get('name'))); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH E:\project-2023\smpn-2\web-smpn2\resources\views/components/input/file.blade.php ENDPATH**/ ?>